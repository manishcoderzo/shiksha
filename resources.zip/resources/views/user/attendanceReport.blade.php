@extends('user.layout.app')
@section('content')
<?php

    $checkin = json_decode($todayCheckin[0]->atten);
    $checkout = json_decode($todayCheckout[0]->atten);

?>
<div class="p-2 m-2 top-content border-bottom">
     <p class="h6" style="font-weight: 600;">
        <a href="{{route('user.dashboard')}}" style="color:black">
            <i class="fa-solid fa-less-than" style="margin-right: 10px;"></i>Attendance Reports</a>
    </p>
</div>

<div class="p-2 m-2">
    <div class="row">
        <div class="col-6">
            <div class="card" style="width: 100%;">
              <div class="card-body">
                <h5 class="card-title">Total Teacher</h5>
                <p class="card-text">{{$data->count()}}</p>
              </div>
            </div>
        </div>
        <div class="col-6">
            <div class="card" style="width: 100%;">
              <div class="card-body">
                <h5 class="card-title">Today Present</h5>
                <h6 class="card-subtitle mb-2 text-muted">CheckIn Time</h6>
                <p class="card-text">{{$todayCheckin->count()}}</p>
              </div>
            </div>
        </div>
        <div class="col-6 mt-2">
            <div class="card" style="width: 100%;">
              <div class="card-body">
                <h5 class="card-title">Today Absent</h5>
                <h6 class="card-subtitle mb-2 text-muted">Checkin Time</h6>
                <p class="card-text">{{$data->count() - $todayCheckin->count()}}</p>
              </div>
            </div>
        </div>
        <div class="col-6 mt-2">
            <div class="card" style="width: 100%;">
              <div class="card-body">
                <h5 class="card-title">Today Present</h5>
                <h6 class="card-subtitle mb-2 text-muted">CheckOut Time</h6>
                <p class="card-text">{{$todayCheckout->count()}}</p>
              </div>
            </div>
        </div>
        <div class="col-6 mt-2">
            <div class="card" style="width: 100%;">
              <div class="card-body">
                <h5 class="card-title">Today Absent</h5>
                <h6 class="card-subtitle mb-2 text-muted">CheckOut Time</h6>
                <p class="card-text">{{$data->count() - $todayCheckout->count()}}</p>
              </div>
            </div>
        </div>
    </div>
    <p class="h6 border-bottom mt-4" style="font-weight: 600;">
      Check-in Time Present and Absent
    </p>
    <div class="row">
        @foreach($data as $d)
        <input type="hidden" name="staffId[]" value="{{$d->id}}">
        <div class="col-12 mt-2">
            <div class="d-flex justify-content-between user-c-name">
                <p id="teacher-name">
                    <a href="{{route('user.teacherDetails',[$d->id])}}" style="color:black;text-decoration: none;"> 
                    @if($d->photo != '' && file_exists(public_path().'/superadmin/profileImage/'.$d->photo))
                    <img src="{{asset('superadmin/staff/'.$d->photo)}}" class="user-image">
                    @else
                    <img src="{{asset('assets/images/noimage.png')}}" class="user-image">
                    @endif
                    <!-- <img src="{{asset('assets/images/avatars/03.png')}}" class="user-image"> -->
                    <span class="ml-2">{{$d->name}}</span></a>
                </p>
                <p class="checkbox-design">
                    
                
                    <input class="form-check-input" name="atten[]" type="checkbox" id="inlineCheckbox1" value="{{$d->id}}" 
                    @foreach($checkin as $j)
                    {{$j == $d->id ? 'checked' : ''}} 
                    @endforeach
                     disabled/>
                   
                </p>
            </div>
        </div>
         @endforeach
    </div>
    <p class="h6 border-bottom" style="font-weight: 600;">
      Check-Out Time Present and Absent
    </p>
    <div class="row">
        @foreach($data as $d)
        <input type="hidden" name="staffId[]" value="{{$d->id}}">
        <div class="col-12 mt-2">
            <div class="d-flex justify-content-between user-c-name">
                <p id="teacher-name">
                    <a href="{{route('user.teacherDetails',[$d->id])}}" style="color:black;text-decoration: none;"> 
                    @if($d->photo != '' && file_exists(public_path().'/superadmin/profileImage/'.$d->photo))
                    <img src="{{asset('superadmin/staff/'.$d->photo)}}" class="user-image">
                    @else
                    <img src="{{asset('assets/images/noimage.png')}}" class="user-image">
                    @endif
                    <!-- <img src="{{asset('assets/images/avatars/03.png')}}" class="user-image"> -->
                    <span class="ml-2">{{$d->name}}</span></a>
                </p>
                <p class="checkbox-design mb-4">
                    <input class="form-check-input" name="atten[]" type="checkbox" id="inlineCheckbox1" value="{{$d->id}}"
                     @foreach($checkout as $s)
                    {{$s == $d->id ? 'checked' : ''}} 
                    @endforeach 
                    disabled />
                </p>
            </div>
        </div>
         @endforeach
    </div>
</div>

@include('user.layout.footernav')

@endsection
