<!--start footer-->
<footer class="footer">
    <div class="footer-text">
        Copyright ©
        <script>
            document.write(new Date().getFullYear())
        </script>. All right reserved.
    </div>
</footer>
<!--end footer-->
