<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    use HasFactory;
    public function schoolList(){
        return $this->hasOne(School::class,'id','schoolId');
    }
    public function staffTypeList(){
        return $this->hasOne(StaffType::class,'id','staffTypeId');
    }
}
