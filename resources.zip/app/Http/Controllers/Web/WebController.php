<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Staff;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Headmaster;
use App\Models\Attendance;
use App\Models\AttendanceManage;
use Carbon\Carbon;
class WebController extends Controller
{
    
    public function otpVarification(){
        return view('user.auth.opt-varification');
    }
    public function home(){
        $data = Staff::where('schoolId',Auth('headmasters')->user()->schoolId)->get();
        //dd(Auth('headmasters')->user()->schoolId);
        return view('user.home',compact('data'));
    }
    public function dashboard(){
        $data = Staff::where('schoolId',Auth('headmasters')->user()->schoolId)->get();
        //dd(Auth('headmasters')->user()->schoolId);
        $school = Headmaster::with(['schoolList'])->where('id',Auth('headmasters')->user()->id)->first();
        return view('user.dashboard',compact('data','school'));
    }
    public function account(){
        //dd(Auth('headmasters')->user()->schoolId);
        return view('user.account');
    }
    public function attendance(){
        $head = Headmaster::where('schoolId',Auth('headmasters')->user()->schoolId)->first();
        //dd($head);
        $data = Staff::where('schoolId',Auth('headmasters')->user()->schoolId)->get();
        $today = Carbon::now()->toDateString();
        $todayCheckout = Attendance::
            whereDate('created_at', $today)
            ->where([['headmasterId',Auth('headmasters')->user()->id],['status','1']])
            ->first();
        $todayCheckin = Attendance::
        whereDate('created_at', $today)
        ->where([['headmasterId',Auth('headmasters')->user()->id],['status','0']])
        ->first();
        return view('user.attendance',compact('data','head','todayCheckout','todayCheckin'));
    }

    public function attendanceSubmit(Request $request){
        $validator = Validator::make($request->all(),[
            'status' => 'required',
            // 'selfie' => 'required',
        ]);


        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $today = Carbon::now()->toDateString();

        $existingAttendance = Attendance::
            whereDate('created_at', $today)
            ->where('headmasterId',Auth('headmasters')->user()->id)->where('status', $request->status)
            ->first();
        // $attendanceCount = Attendance::
        //     whereDate('created_at', $today)->where('headmasterId',Auth('headmasters')->user()->id)
        //     ->count();

      
        if (!$existingAttendance) {
            $head = new Attendance();
            // if($request->selfie){
            //     $photoData  =$request->selfie;
            //      $photoData = substr($photoData, strpos($photoData, ',') + 1);
            //      $filename = 'captured_photo_' . time() . '.jpg'; // Generate a unique filename
            //     $filePath = public_path('superadmin/selfie/' . $filename); // Path to save the photo in the public folder

            //     // Save the image file
            //     file_put_contents($filePath, base64_decode($photoData));
            //      $head->selfie = $filename;
            // }
            $head->schoolId = $request->schoolId;
            $head->status = $request->status;
            $head->headmasterId = Auth('headmasters')->user()->id;
            $head->save();

            $manage = new AttendanceManage();
            $manage->staffId = json_encode($request->staffId);
            $manage->schoolId = $request->schoolId;
            $manage->status  = $head->status;
            $manage->attendanceId  = $head->id;
            $manage->atten  = json_encode($request->atten);
            $manage->headmasterId = Auth('headmasters')->user()->id;
            $manage->save();
            return redirect()->route('user.attendanceImage',$head->id)->with('success','succesfully for next step');
        }else{
            return redirect()->back()->with('failed','Attendance already marked for today');
        }
        
    }
    public function attendanceImage($id){
        return view('user.attendanceImage',compact('id'));
    }
    public function attendanceImageSubmit(Request $request){
        $validator = Validator::make($request->all(),[
            'selfie' => 'required',
            'attendanceImage' => 'required',
        ]);


        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
        }
        // $todayImageCheck = Attendance::
        // whereDate('created_at', $today)
        // ->where([['headmasterId',Auth('headmasters')->user()->id],['status','0']])
        // ->first();
        $attendanceId = $request->attendanceId;
        $head = Attendance::find($attendanceId);
        if($request->selfie){
            $photoData  =$request->selfie;
             $photoData = substr($photoData, strpos($photoData, ',') + 1);
             $filename = 'captured_photo_' . time() . '.jpg'; // Generate a unique filename
            $filePath = public_path('superadmin/selfie/' . $filename); // Path to save the photo in the public folder

            // Save the image file
            file_put_contents($filePath, base64_decode($photoData));
             $head->selfie = $filename;
        }
        if($request->attendanceImage){
            $photoDatas  =$request->attendanceImage;
             $photoDatas = substr($photoDatas, strpos($photoDatas, ',') + 1);
             $filename = 'captured_photo_' . time() . '.jpg'; // Generate a unique filename
            $filePath = public_path('superadmin/attendanceImage/' . $filename); // Path to save the photo in the public folder

            // Save the image file
            file_put_contents($filePath, base64_decode($photoDatas));
             $head->registerImage = $filename;
        }
        $head->save();
        return redirect()->route('user.home')->with('success','Attendance marked succesfully');
    }

    public function headmasterProfile(){
        return view('user.auth.headmasterProfile');
    }
    public function headmasterProfileSubmit(Request $request){
        $validator = Validator::make($request->all(),[
            'photo' => 'required|mimes:jpeg,jpg,png',
        ]);

        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
        }
        $id = $request->id;
        // dd($id);
        $data = Headmaster::find($id);
        if($request->photo){
            $ext = $request->photo->getClientOriginalExtension();
            $newFileName =  time().'.'.$ext;
            $request->photo->move(public_path().'/superadmin/headmaster/',$newFileName); 
            $data->photo = $newFileName;
            $data->save();
        }        
        return redirect()->back()->with('success','Your Profile Update succesfully');
    }
    public function teacherDetails($id){
        $data = Staff::with(['schoolList'])->where('id',$id)->first();
        return view('user.teacherDetails',compact('data'));
    }
    public function attendanceReport(){
        $data = Staff::where('schoolId',Auth('headmasters')->user()->schoolId)->get();
        $today = Carbon::now()->toDateString();
        $todayCheckout = AttendanceManage::
            whereDate('created_at', $today)
            ->where([['headmasterId',Auth('headmasters')->user()->id],['status','1']])
            ->get();
        $todayCheckin = AttendanceManage::
        whereDate('created_at', $today)
        ->where([['headmasterId',Auth('headmasters')->user()->id]],['status','0'])
        ->get();
        return view('user.attendanceReport',compact('data','todayCheckout','todayCheckin'));
    }
}
