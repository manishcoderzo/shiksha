<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\School;
use App\Models\State;
use App\Models\District;
use App\Models\Block;

class SchoolController extends Controller
{
    public function schoolList(){
        if(Auth('web')->user()->userType == '1'){
            $data = School::where('block',Auth('web')->user()->blockId)->get();
        }else{
            $data = School::get();
        }
        
        return view('superAdmin.school.list',compact('data'));
    }
    public function schoolCreate(){
        $state = State::get();
        return view('superAdmin.school.create',compact('state'));
    }
    public function schoolSubmit(Request $request){
        $validator = Validator::make($request->all(),[
            'schoolName' => 'required',
            'address' => 'required',
            'state' => 'required',
            'district' => 'required',
            'block' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
        ]);

        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
        }
      
        $data = new School();
        $data->schoolName = $request->schoolName;
        $data->address = $request->address;
        $data->state = $request->state;
        $data->district = $request->district;
        $data->block = $request->block;
        $data->latitude = $request->latitude;
        $data->longitude = $request->longitude;
        $data->userId = Auth('web')->user()->id;
        $data->save();

        
        return redirect()->back()->with('success','School add succesfully');
    }
    public function schooldelete($id){
        School::where('id',$id)->delete();
        return redirect()->back();
    }
    public function schoolEdit($id){
        $data = School::where('id',$id)->first();
        $state = State::get();
        $district = District::get();
        $block = Block::get();
        return view('superAdmin.school.edit',compact('state','district','block','data'));
    }
    public function schoolUpdate(Request $request,$id){
        $validator = Validator::make($request->all(),[
            'schoolName' => 'required',
            'address' => 'required',
            'state' => 'required',
            'district' => 'required',
            'block' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
        ]);

        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
        }
      
        $data = School::find($id);
        $data->schoolName = $request->schoolName;
        $data->address = $request->address;
        $data->state = $request->state;
        $data->district = $request->district;
        $data->block = $request->block;
        $data->latitude = $request->latitude;
        $data->longitude = $request->longitude;
        $data->userId = Auth('web')->user()->id;
        $data->status = $request->status;
        $data->save();

        
        return redirect()->back()->with('success','School Update succesfully');
    }
}
